var setup = function() {
  createGraphics(600, 400);
};

var draw = function() {
  background(250, 250, 50);

	strokeWeight(10);
	line(100, 100, 100, 300);
	line(120, 100, 120, 300);
	line(140, 100, 140, 300);
	line(160, 100, 160, 300);
	
};