var setup = function() {
  createGraphics(200, 200);
};

var draw = function() {
  background(250, 250, 50);
  fill(255, 0, 0);
  rect(0, 0, 50, 50);
  fill(0, 255, 0);
  ellipse(100, 100, 100, 50);
};