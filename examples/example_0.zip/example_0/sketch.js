var setup = function() {

  createGraphics(600, 400);

};

var draw = function() {

  // background
  background(250,250,100);

  // ellipse
  fill(250,200,200);
  ellipse(100,100,100,100);

  //rectangle
  fill(200,250,200);
  rect(400,100,50,50);

};