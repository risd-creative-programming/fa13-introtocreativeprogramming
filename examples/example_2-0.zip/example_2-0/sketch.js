

// Setup is used to define starting values, size, load images and assets.
// The code in this block is run once at the very beginning.

var setup = function() {

	print("I'm starting");

};


// Draw runs like a loop, over and over, each trip through draw is called a frame.

var draw = function() {

	print("I'm drawing");
	print(frameCount);

};